//
//  Block2App.swift
//  Block2
//
//  Created by Oleksandr Hryhoruk on 2025-02-12.
//

import SwiftUI

@main
struct Block2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
